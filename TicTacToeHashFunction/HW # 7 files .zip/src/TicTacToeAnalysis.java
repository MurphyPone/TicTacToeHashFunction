//A testing class used to compare each of the three HashCode methods
public class TicTacToeAnalysis {
	public static void main(String[] args) {
		TicTacToeHashCode one = new TicTacToeHashCode("The First Board");
		TTT_HC two = new TTT_HC();
		TicTacToeHashMap three = new TicTacToeHashMap();
		

	}

}
